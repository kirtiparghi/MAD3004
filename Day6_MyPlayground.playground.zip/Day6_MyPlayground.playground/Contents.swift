//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

class Employee {

    var eid: Int?
    var ename: String?
    var salary:Double?

    //Default Constructor
    init() {
        self.eid = 0
        self.ename = String()
        self.salary = 0.0
        print("(c) Employee")
    }

    init(employeeId eid:Int, employeeName ename:String, employeeSalary salary:Double) {
        self.eid = eid
        self.ename = ename
        self.salary = salary
    }

//    convenience init(emp:Employee) {
//        self.init(employeeId: emp.eid!, employeeName: emp.ename!, employeeSalary: emp.salary!)
//    }
//
    func display() {
        print(self.eid!,self.ename!,self.salary!)
    }

    func display(title:String) {
        print("asdas")
    }

    deinit {
        print("Employee object Destroyed")
    }
}

var e1 = Employee()
//Employee.display(e1)
//print(e1.eid!,e1.ename!,e1.salary!)
e1.display()
e1.display(title : "dfas")

var e2 = Employee(employeeId: 1, employeeName: "Kirti Parghi", employeeSalary: 90000)
e2.display()

e1 = e2
e2 = e1
var e3 = e2

/*
var eid = Int()
var gender = Bool()
var enm = String()
var salary = Double()
print(eid,gender,enm,salary)
*/

/**
 INHERITANCE
 ***********************/

class FullTimeEmployee : Employee {

    var noOfPaidLeaves:Int?

    override init() {
        super.init()
        self.noOfPaidLeaves = 10
        print("(c) Fulltime Employee")
    }

    init(employeeId eid:Int, employeeName ename:String, employeeSalary salary:Double, noOfPaidLeaves : Int) {
        super.init(employeeId: eid, employeeName: ename, employeeSalary: salary)
        self.noOfPaidLeaves = noOfPaidLeaves
    }

    func display(welcome:String) {
        print("\(welcome), Welcome to full time family")
    }

    override func display() {
        super.display()
        print("No. Of Leave \(self.noOfPaidLeaves!)")
    }


}

var fullTimeEmp = FullTimeEmployee(employeeId: 1, employeeName: "Kirti", employeeSalary: 20000, noOfPaidLeaves: 1)
fullTimeEmp.display()

var fullTimeEmp1 = FullTimeEmployee(employeeId: 2, employeeName: "John", employeeSalary: 10000, noOfPaidLeaves: 2)
fullTimeEmp1.display()

class ParttimeEmployee: Employee {

    var inTime:String?
    var outTime:String?
    var noOfHours:Int?

    override init() {
        super.init()
        self.inTime = "1:00 PM"
        self.outTime = "5:00 PM"
        self.noOfHours = 4
        print("(c) Partime Employee")
    }

    init(employeeId eid:Int, employeeName ename:String, employeeSalary salary:Double, inTime : String, outTime:String, noOfHours:Int) {
        super.init(employeeId: eid, employeeName: ename, employeeSalary: salary)
        self.inTime = inTime
        self.outTime = outTime
        self.noOfHours = noOfHours
    }

    override func display() {
         super.display()
        print("In time : \(self.inTime!)")
        print("Out time : \(self.outTime!)")
        print("No Of Hours : \(self.noOfHours!)")
    }

    func calculateHours() {
        print(self.noOfHours)
    }
}

var partimeEmp = ParttimeEmployee(employeeId: 1, employeeName: "Kirti", employeeSalary: 4000, inTime: "9:00 AM", outTime: "5:00 PM", noOfHours: 8)
partimeEmp.display()
partimeEmp.calculateHours()

var partimeEmp1 = ParttimeEmployee(employeeId: 2, employeeName: "John", employeeSalary: 4000, inTime: "10:00 AM", outTime: "5:00 PM", noOfHours: 7)
partimeEmp1.display()
partimeEmp1.calculateHours()

var states = ["California", "New York", "Texas", "Alaska"]

let abbreviatedStates = states.map({ (state: String) -> String in
    let index = state.index(state.startIndex, offsetBy: 2)
    return state.substring(to: index).uppercased()
})

print(abbreviatedStates)

var array = ["a","b","c","d"]

func buildItem(name: String) -> [String:Any] {
    let action : [String: Any] = [
        "name": name
    ]
    return action
}

var items = [String:Any]()
var index = 0
for filename in array {
    print(filename)
    let action : [String: Any] = [
        "name": name
    ]
    items.ap
    index = index + 1
}



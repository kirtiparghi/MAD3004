//
//  main.swift
//  Day9_StudentExample
//
//  Created by MacStudent on 2017-10-04.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var student1:Student = Student(sid: 1, snm: "Kirti")
student1.display()
